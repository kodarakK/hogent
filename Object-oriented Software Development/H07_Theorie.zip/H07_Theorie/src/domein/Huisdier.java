package domein;

public class Huisdier {

	
	
	
	
	
	
	//this.getClass().getSimpleName()
	//JAVA weet naar welk object je toString hebt gestuurd
	//in geval van Kat kat = new Kat("..."); 
	             //kat.toString() ==> Kat
	//Analoog voor de hond ==> Hond
	
	//getSimpleName(): geeft de naam van de klasse terug
}
