package domein;

public class DomeinController
{

}
