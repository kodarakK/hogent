package dto;

public record DoosDTO(double lengte, double breedte, double hoogte, String kleur, String code)
{

}
