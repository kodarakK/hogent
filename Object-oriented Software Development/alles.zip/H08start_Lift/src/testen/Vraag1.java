package testen;

public class Vraag1 {

/*
Test-case 1.1  willekeurig
- laagsteVerdieping = -1000
- hoogsteVerdieping = 1000
- verwacht resultaat = 	maakt									maaktLift   werptException

Test-case 1.2 grens
- laagsteVerdieping = -1
- hoogsteVerdieping = 80 //willekeurig
- verwacht resultaat = maakt

Test-case 1.3
- laagsteVerdieping = -10 //wk
- hoogsteVerdieping = 1
- verwacht resultaat = maakt

Test-case 1.4
- laagsteVerdieping = 0 //net niet
- hoogsteVerdieping = 10 //
- verwacht resultaat = werpt

Test-case 1.5
- laagsteVerdieping = -1 //wk
- hoogsteVerdieping = 0 //net niet
- verwacht resultaat = werpt

Test-case 1.6
- laagsteVerdieping = 10 // te hoog
- hoogsteVerdieping = 10 // goe
- verwacht resultaat = werpt 

Test-case 1.7
- laagsteVerdieping = -10 // goe
- hoogsteVerdieping = -10 // te laag
- verwacht resultaat =  werpt

*/
}