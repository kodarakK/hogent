package utils;

public enum Kleur
{
	BLAUWE, GROENE, GELE, RODE, ROZE, WITTE, PAARSE;
}
