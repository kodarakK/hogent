package domein;

public class VoorbeeldVP
{

	private int getal;
	
	private String woord;
	
	private VoorbeeldVP(String woord) {
			
	}

	public void vermeerderen()
	{
		throw new UnsupportedOperationException();
	}

	public VoorbeeldVP()
	{
		throw new UnsupportedOperationException();
	}
}
