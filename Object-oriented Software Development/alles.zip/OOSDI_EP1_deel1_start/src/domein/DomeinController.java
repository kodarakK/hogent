package domein;

import domein.Tuincentrum;
import domein.Plant;
import dto.PlantDTO;


public class DomeinController 
{
	private Tuincentrum tuincentrum;
	private PlantDTO[] plantenDTOs;

	public DomeinController() {
        tuincentrum = new Tuincentrum();
	}

	public void voegPlantToe(String naam, char soortCode, int hoogteInCm, double prijsInEuro, int aantalInVoorraad) {
        tuincentrum.voegPlantToe(new Plant(naam, soortCode, hoogteInCm, prijsInEuro, aantalInVoorraad));
		
	}

	public PlantDTO[] geefAllePlanten(boolean inVoorraad) {
		//TODO
		
		
		for (Plant p : tuincentrum.geefPlanten(false))
		{	
			Planten			
		}
	}

	
	public double bepaalWaardeVerkoop()
	{
		//TODO
	}

	public int[] maakOverzichtPlantenPerHoogte() 
	{
		//TODO
	}

}
