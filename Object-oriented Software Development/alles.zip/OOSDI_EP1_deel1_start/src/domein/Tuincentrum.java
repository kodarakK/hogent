package domein;

import java.util.List;

import persistentie.PlantMapper;

public class Tuincentrum 
{
	private List<Plant> planten;
	private final PlantMapper plantMapper;

	public Tuincentrum() 
	{
		plantMapper = new PlantMapper();
		this.planten = plantMapper.geefPlanten();
	}

	public void voegPlantToe(Plant plant) 
	{ 
		for (Plant p : planten)
		{
			if (p.getNaam() == plant.getNaam())
				p.setAantalInVoorraad(
                        p.getAantalInVoorraad() + plant.getAantalInVoorraad());
			else
				planten.add(plant);
		}
	}

	public List<Plant> getPlanten() {
		return planten;
	}

	public int[] maakOverzichtPlanten() {
		int[] uitvoerList = new int[3];

		for (Plant p : planten) {
			if (p.getHoogteInCm() < 80) 
				uitvoerList[0] += 1;
			else if (p.getHoogteInCm() > 80 && p.getHoogteInCm() < 100)
				uitvoerList[1] += 1;
			else if (p.getHoogteInCm() > 100)
				uitvoerList[2] += 1;
		}

		return uitvoerList;

	}
	
	

	public double bepaalWaardeVerkoop() {
        double totaal = 0;

        for (Plant p : planten) 
            totaal += p.getPrijsInEuro();
		
		return totaal;
	}

	//TODO geefPlanten
	public List<Plant> geefPlanten(boolean inVoorraad) {
		List<Plant> enkelInVoorraad = null;
		if (inVoorraad) {
            for (Plant p : planten) {
                if (p.getAantalInVoorraad() > 0)
                	enkelInVoorraad.add(p);
            }
            return enkelInVoorraad;

        }
        else 
            return planten;
	}
}	
