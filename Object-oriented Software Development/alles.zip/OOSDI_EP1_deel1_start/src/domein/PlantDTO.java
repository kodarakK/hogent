package dto;

public record PlantDTO(String naam, char soortCode, int hoogteInCm,
                       double prijsInEuro, int aantalInVoorraad) {



}
