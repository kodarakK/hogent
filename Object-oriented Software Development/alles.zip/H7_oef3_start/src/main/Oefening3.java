package main;

public class Oefening3 {

/*	 
Huisdier dier = new Duif("Grijsje");
FOUT: geen ringnr, geen contructor met 1 arg in klasse Duif

Huisdier dier = new Huisdier("Pluk");
CORRECT


Kat kat = new Huisdier("Felix");
een huisdier is een kat: niet correct
NIET CORRECT: een superklasse kunnen we niet toekennen aan een subklasse

Duif duif = new Duif("Knabbel",20181111111L);
return duif.getNaam();
CORRECT
get naam staat in klasse huisdier
Duif is een Huisdier, duif mag alle niet private methoden 
oproepen van Huisdier en van Object


Huisdier dier = new Kat("Goofie");
return dier.spin();
NIET CORRECT: methode spin() komt niet voor in klasse huisdier

Object oboject = new Kat("Goofie");
Kat is een Huisdier, Huisdier is een Object

Kat dier = new Kat("Goofie");
return dier.spin();
CORRECT, methode spin() komt voor in de klasse Kat

Duif duif = new Hond("Tarzan");
return duif.kwispel();
NIET CORRECT, een subklasse kan niet toegekend worden 
aan een andere subklasse


Huisdier dier = new Hond("Tarzan");
return ((Hond)dier).kwispel();
CORRECT, niet aan te raden


*/
}
