package voorbeeldAssosiatie;

public class DomeinController
{
}
