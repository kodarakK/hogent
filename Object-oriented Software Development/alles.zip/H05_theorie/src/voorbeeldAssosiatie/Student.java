package voorbeeldAssosiatie;

public class Student
{
}
