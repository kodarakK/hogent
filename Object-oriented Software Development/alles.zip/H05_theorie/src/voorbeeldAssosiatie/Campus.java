package voorbeeldAssosiatie;

import java.util.*;

public class Campus
{

	private List<Student> studenten;
}
