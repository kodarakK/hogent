public class DomeinController
{

	private StudentRepository StudentRepository;

	public void inschrijven(String naam, int studentnr)
	{
		throw new UnsupportedOperationException();
	}
}
