public class Student
{

	private String naam;
	private int studentnr;

	public Student(String naam, int studentnr)
	{
		throw new UnsupportedOperationException();
	}
}
