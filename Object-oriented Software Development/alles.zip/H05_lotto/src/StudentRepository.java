
import java.util.*;

public class StudentRepository
{

	private Collection<Student> studenten;

	public void voegToe(Student student)
	{
		throw new UnsupportedOperationException();
	}
}
