package dto;

public record KapitaalDTO(double bedrag, double intrest) {

}
