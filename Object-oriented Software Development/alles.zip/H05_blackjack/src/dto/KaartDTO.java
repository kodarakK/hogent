package dto;

public record KaartDTO(String waarde, String kleur) {
    
}
