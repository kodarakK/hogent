public class Fiets
{

	private String kleur;
	private String merk;
	private int aantalVersnellingen;
	private boolean herenFiets;
	private double snelheid;
	
	public Fiets(String kleur)
	{
		throw new UnsupportedOperationException();
	}

	public String getKleur()
	{
		return this.kleur;
	}

	public void setAantalVersnellingen(int value)
	{
		this.aantalVersnellingen = value;
	}

	public void versnelTotMax(double max)
	{
		throw new UnsupportedOperationException();
	}

	
}
