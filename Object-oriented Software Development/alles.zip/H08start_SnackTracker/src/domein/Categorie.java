package domein;

public enum Categorie {
	GROENTE, FRUIT, SNOEP
}
