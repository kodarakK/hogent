package domein;

public class Rekening
{

}
