package cui;

public class Oefening10 {

	//Vind de fouten in volgend stukje code:

	/*
	final int MAX = 10;  / moet dat static zijn?
	int[][] table = new int [MAX][MAX]; / is goed
	for (int i= 0; i <= table.length; i++) // '<' ipv '<='
		for (int j= 0; j <= table[j].length; j++) // '<' ipv '<=' en table[i] ipv table[j] en betere namen
			table[i,j] = i+ j / table[i][j]

    */
}
