package cui;

public class Oefening1 {

	//Zoek de fout
	
	/*
//	OPDRACHT 1:
	 
	private static final int MAX = 3;
	int[] table = {1,2,3};
	
	
//	OPDRACHT 2;
	int max = 5;
	int[] table1 = new int[max];
	
	table1[max - 1] = 5;
	max++;
	int table2[] = new int[max];
	
	
	*/
	
	

}
