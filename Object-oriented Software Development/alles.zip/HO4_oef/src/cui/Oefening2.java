package cui;

public class Oefening2 {

	/*
	int[] getallen = new int[10];
	getallen[9] = 90;
	getallen[0] = 100;
	getallen[1] = getallen[9 - 8];
	getallen[2] = getallen[0] * 2;
	getallen[3] = getallen[2] + getallen[0];
	getallen[4] = getallen[9] * 10;
	for (int i = 5; i <= 9; i++) {
		getallen[i] = i * 2;
	}

	// Array getallen:
		0	1	2	3	4	5	6	7	8	9
	  -----------------------------------------
	  |   |   |   |   |   |   |   |   |   |   |
	  -----------------------------------------
	  
 */

 /*
      	int[] getallen1 = new int[3];
		int[] getallen2 = getallen1;
		getallen1[1] = 100;
		getallen1 = new int[3];
		getallen2[1] = 500;

		// Array getallen1:
			0	1	2
		  -------------
		  |   |   |   |
		  -------------

		// Array getallen2:
			0	1	2
		  -------------
		  |   |   |   |
		  -------------	
 */
}
