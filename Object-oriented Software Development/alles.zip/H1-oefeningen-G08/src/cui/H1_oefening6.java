package cui;

public class H1_oefening6
{

	public static void main(String[] args)
	{
		int ontvangenBedrag = 100, teBetalen = 45;
		System.out.printf("Te betalen = %d %nOntvangen bedrag = %d %nTerug = %d", teBetalen, ontvangenBedrag, ontvangenBedrag - teBetalen);
	}

}
