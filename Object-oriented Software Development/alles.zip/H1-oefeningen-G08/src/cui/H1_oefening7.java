package cui;

public class H1_oefening7
{

	public static void main(String[] args)
	{
		System.out.print("Open de \"folders\"! \nD:\\temp\\OOSDI");
		System.out.print("Mijn naam is \"Jan Janssens\",\nIk volg de opleiding \'Toegepaste Informatica\'!\n");
		System.out.printf("85 - 95 = %d", 85 - 95);
	}

}
