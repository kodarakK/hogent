package cui;

public class H1_oefening5
{

	public static void main(String[] args)
	{
		int getal = 2;
		System.out.printf("Getal = %d%nGetal + 1 = %d%nGetal - 1 = %d", getal, getal + 1, getal -1);
	}

}
