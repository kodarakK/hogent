public class Welcome1 {
  public static void main(String[] args) {
    System.out.print("Welkom to ");
    System.out.println("Java \nprogamming")
  }
}
