int = %d (decimaal, primitief)
int = %o (octaal)
int = %x (hexadecimaal, hoofdlettergevoelig)
%d'%n' = newline character
%..10 = veldbreedte

int / int = gehele deling: 7/2 = 3
int % int = rest deling: 7%2 = 1


Scanner --> java.util
int: nextInt();
string: nextLine();
