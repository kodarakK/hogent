public class Som {
  public static void main(String[] args) {
    int x=2, y=3, som;
    som=x*x + y*y;
    System.out.println("Som = "+som);
  }
}
