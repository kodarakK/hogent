package cui;

public class Som
{

	public static void main(String[] args)
	{
		int x = 2, y = 3, som = 13;
		som = x*x + y*y;
		System.out.printf("x = %d, y = %d, som = %d", x, y, som);
		
		
//		int getal1 = 10;
//		int getal2 = 20;
//		double getal3 = 363.3636;
//		System.out.println("x = " + x + ", y = " + 3 + ", som = " + som);
//		System.out.println("Som = "+som);
//		System.out.printf("Som = %x, x = %x, y = %o", som, x, y);
//		System.out.printf("Som  = %10d%-10d%n", som , x);
		
		
		// 2.2 oef 2
//		System.out.println("Open de map C:\\Mijn Documenten \nVolg de pijl \"Omleiding\"\nHet boek voor \t Java\nis dat van \t\tDeitel\nEngelstalig");
		
		// 2.3 oef 3
//		30 spaces string tab 'getal1 + getal2'
//		System.out.printf("%30s\t", "getal1 + getal2");
//		4 spaces (som getallen) newline
//		System.out.printf("", );
//		verschil getallen tab getal3(float) 3tab stringHL newline
//		1space berekening newline
//		tab getal3(float op 3 decimalen)
		
		
	}

}
