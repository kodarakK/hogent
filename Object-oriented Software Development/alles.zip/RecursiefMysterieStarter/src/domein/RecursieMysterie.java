package domein;

public class RecursieMysterie {

	/*
	private int mysterie(int a, int b) {
		if (b == 1)
			return a;
		return a + mysterie(a, b - 1);
	}*/
	
	 /*
	 Wat is het resultaat van de methode-aanroep mysterie(3, 4)?
	3 + 3 + 3 + 3 = 12

     Kan je een algemene omschrijving geven van wat mysterie als resultaat heeft?
	3*4

     Wat gebeurt er bij de methode aanroep mysterie(3, -4)?
	inf loop
	 
	 
	
	private int mysterie(int a, int b) {
		if (b < 1) throw new IllegalArgumentException("b moet groter of gelijk zijn aan 1");
		if (b == 1)
			return a;
		return a + mysterie(a, b - 1);
		*/
}
