package cui;

public class VoorbeeldMain_args {

	/* Array van args opvullen: 
	 In de Eclipse IDE kies je hiervoor in het <Run> menu voor <Run configurations>. 
	 Op het tabblad arguments kan je een lijst van waarden ingeven gescheiden door een spatie. 
	 Deze waarden worden als Strings in een array verzameld en doorgegeven aan args bij de start van je programma…​
	 */
	
	public static void main(String[] args) {
		String antwoord = switch (args.length)
		{
			case 0 -> "Geen parameters";
			case 1 -> String.format("1 parameter = %s%n", args[0]);
			default -> String.format("parameters %s en %s%n", args[0], args[1]);
		};
		System.out.println(antwoord);
	}
	
}