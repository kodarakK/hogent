package domein;

public class Rechthoek {
	private double lengte;
	private double breedte;
	
	//static attribuut -> STATIC = alle instanties(=objecten) van Rechthoek
	//hebben 0 als aantalRechthoeken, waarde kan gewijzigd worden: 
	private static int aantalRechthoeken;
	
	//static constante -> FINAL = waarde kan niet gewijzigd worden
	//STATIC = alle instanties van Rechthoek hebben 10 als DEFAULT_BOVENGRENS 
	private static final int DEFAULT_BOVENGRENS = 10;
	//Idem voor BOVENGRENS
	private static final int BOVENGRENS = 100;
	
	public Rechthoek(double lengte, double breedte) {
		setLengte(lengte);
		setBreedte(breedte);
		aantalRechthoeken++;
	}

	public Rechthoek() {
		this(DEFAULT_BOVENGRENS, DEFAULT_BOVENGRENS);
	}
	
	public double getLengte() {
		return lengte;
	}

	public double getBreedte() {
		return breedte;
	}

	public final void setLengte(double lengte) {
		//this.lengte = (lengte <= 0 || lengte > BOVENGRENS)? DEFAULT_BOVENGRENS: lengte;
		if (lengte <= 0 || lengte > BOVENGRENS)
			throw new IllegalArgumentException(String.format("lengte moet strikt positief zijn en kleiner of gelijk aan %d%n", DEFAULT_BOVENGRENS));
		this.lengte = DEFAULT_BOVENGRENS;
		
//		niet goed: 
//			if (correct) this.lengte = lengte;
//			else 
//				throw new IllegalArgumentExcpetion();
	}

	public final void setBreedte(double breedte) {
//		this.breedte = (breedte <= 0 || breedte > BOVENGRENS)? DEFAULT_BOVENGRENS: breedte;
		if (breedte <= 0 || breedte > BOVENGRENS)
			throw new IllegalArgumentException(
					String.format("breedte moet strikt positief zijn en kleiner of gelijk aan %d%n", DEFAULT_BOVENGRENS));
		this.breedte = breedte;
	}

//STATIC methode
	public static int getAantalRechthoeken() {
		return aantalRechthoeken;
	}

	public double geefOppervlakte() {
		return lengte * breedte;
	}

	public double geefOmtrek() {
		return 2 * (lengte + breedte);
	}

	@Override
	public String toString() {
		return String.format("Rechthoek van %.2f op %.2f.", lengte, breedte);
	}
}